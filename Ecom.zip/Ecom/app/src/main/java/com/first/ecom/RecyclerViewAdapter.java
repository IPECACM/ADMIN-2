package com.first.ecom;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

import static android.content.Context.MODE_PRIVATE;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {
  String F;
  SharedPreferences sharedPreferences;
    Context context;
    List<product_details> MainImageUploadInfoList;

    public RecyclerViewAdapter(Context context, List<product_details> TempList) {

        this.MainImageUploadInfoList = TempList;
        this.context = context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recylcerview_items, parent, false);

        ViewHolder viewHolder = new ViewHolder(view);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        final product_details UploadInfo = MainImageUploadInfoList.get(position);
// Display all products to user
        holder.productDes.setText(UploadInfo.getProduct_des());
        holder.productId.setText(UploadInfo. getProduct_id());
        holder.productName.setText(UploadInfo.getProduct_name());
        holder.productPrice.setText(UploadInfo.getProduct_price());
        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences sharedPref = context.getSharedPreferences("myKey", MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putString("productid",UploadInfo.getProduct_id()) ;
                editor.apply();
               Intent i= new Intent(context, ProductDetailsUser.class);
//                i.putExtra("product_id",UploadInfo.getProduct_id());
               i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(i);
            }
        });

        //Loading image from Glide library.
        Glide.with(context).load(UploadInfo.getProduct_im()).into(holder.imageView);
    }

    @Override
    public int getItemCount() {

        return MainImageUploadInfoList.size();
    }

    public void filterList(ArrayList<product_details> filteredlist) {
        MainImageUploadInfoList=filteredlist;
        notifyDataSetChanged();
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        public ImageView imageView;
        public TextView productDes;
        public TextView productId;
        public TextView productName;
        public TextView productPrice;
        public CardView cardView;

        public ViewHolder(View itemView) {
            super(itemView);

            imageView = (ImageView) itemView.findViewById(R.id.imageView);
            productDes= (TextView) itemView.findViewById(R.id.productdes);
            productId = (TextView) itemView.findViewById(R.id.productid);
            productName = (TextView) itemView.findViewById(R.id.productname);
            productPrice = (TextView) itemView.findViewById(R.id.productprice);
            cardView=(CardView)itemView.findViewById(R.id.cardview1);
        }
    }
}