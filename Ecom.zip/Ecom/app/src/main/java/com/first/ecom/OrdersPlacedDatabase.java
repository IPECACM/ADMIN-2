package com.first.ecom;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class OrdersPlacedDatabase extends AppCompatActivity {
    // Creating DatabaseReference.
    DatabaseReference AData, OData, OPlaced;
    // Creating RecyclerView.
    RecyclerView recyclerView;
    FirebaseAuth FAuth;
    String currentuser = "";
    // Creating RecyclerView.Adapter.
    com.first.ecom.OrdersDbRecycler adapter;


    // Creating List of ImageUploadInfo class.
    List<product_details> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_orders_placed_database);
        // Assign id to RecyclerView.
        String orderId = getIntent().getStringExtra("orderId");
        recyclerView = (RecyclerView) findViewById(R.id.recyclerView4);
//


// Setting RecyclerView size true.
        recyclerView.setHasFixedSize(true);
        FAuth = FirebaseAuth.getInstance();
        currentuser = FAuth.getCurrentUser().getUid();
// Setting RecyclerView layout as LinearLayout.
        recyclerView.setLayoutManager(new LinearLayoutManager(OrdersPlacedDatabase.this));
        SharedPreferences sharedPreferences = getSharedPreferences("myKey", MODE_PRIVATE);
        String value = sharedPreferences.getString("value", "");


        // AData = FirebaseDatabase.getInstance().getReference("Orders Placed").child("Order ids").child(value);
        AData = FirebaseDatabase.getInstance().getReference("Orders Placed").child("Order ids").child(orderId);

        AData.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                DataSnapshot productsSnapshots = dataSnapshot.child("Products");
                for (DataSnapshot postSnapshot : productsSnapshots.getChildren()) {

                    product_details imageUploadInfo = postSnapshot.getValue(product_details.class);
                    Log.d("OrdersPlacedDatabase", "product_name "+imageUploadInfo.getProduct_name());

                    list.add(imageUploadInfo);
                }
                adapter = new com.first.ecom.OrdersDbRecycler(OrdersPlacedDatabase.this, list);

                recyclerView.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });



    }
}