package com.first.ecom;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class DisplayImagesUser extends AppCompatActivity  {

    // Creating DatabaseReference.
    DatabaseReference FData;
    // Creating RecyclerView.
    androidx.recyclerview.widget.RecyclerView recyclerView;
      private EditText Search;
    // Creating RecyclerView.Adapter.
    RecyclerViewAdapter adapter ;
   private  Button Next;
   int C;
//  static  private int i=0;
//  String Custid;
    TextView Custid;
    private FloatingActionButton floatingActionButton;
    // Creating List of ImageUploadInfo class.
    List<product_details> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_images_user);
        Search = (EditText) findViewById(R.id.search);
         Next=(Button)findViewById(R.id.next);
        Custid=(TextView) findViewById(R.id.CustId);
        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(DisplayImagesUser.this));
        floatingActionButton = (FloatingActionButton) findViewById(R.id.floating);

       // C=Integer.parseInt(CustId.getText().toString());

        FData = FirebaseDatabase.getInstance().getReference("Products");
        SharedPreferences sharedPreferences = getSharedPreferences("myKey", MODE_PRIVATE);
        String value = sharedPreferences.getString("value","");
        Custid.setText(value);

        Next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(DisplayImagesUser.this,ConfirmOrder.class);
                startActivity(i);
            }
        });



        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(DisplayImagesUser.this, CartActivity.class);
                startActivity(i);
            }
        });
        FData.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {

                    product_details imageUploadInfo = postSnapshot.getValue(product_details.class);
                    imageUploadInfo.setProduct_id(postSnapshot.getKey());
                    list.add(imageUploadInfo);

                }

                adapter = new RecyclerViewAdapter(getApplicationContext(), list);
                recyclerView.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        Search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable e) {
                filter(e.toString());


            }
        });


}


    private void filter(String text) {


        ArrayList<product_details> filteredlist=new ArrayList<>();
        for (product_details UploadInfo:list){
            if (UploadInfo.getProduct_des() .toLowerCase().contains(text.toLowerCase()))

            {

                filteredlist.add(UploadInfo);
            }

            else  if(UploadInfo.getProduct_name() .toLowerCase().contains(text.toLowerCase()))
            {
                filteredlist.add(UploadInfo);
            }
        }
        adapter.filterList(filteredlist);
    }

}

