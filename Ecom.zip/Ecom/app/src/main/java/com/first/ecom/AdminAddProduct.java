package com.first.ecom;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.HashMap;

public class AdminAddProduct extends AppCompatActivity {

    String S_name;
    private static final int Gallery_Pick = 1;
    Uri ImageUri;
    String S;
    private String S_Id;
    private String S_price;
    private String S_des;
    // String id="ids";private Button Next;
    //  static int i=0;
  //  private StorageReference FStorage;
    String downloadimageurl;
    //private DatabaseReference FDatabase;
    String CategoryName;
    ImageView AddProduct;
    EditText P_Name,P_Des,P_Price,P_id;
    Button Add,Next;
 DatabaseReference FData;
 StorageReference Fstorage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_add_product);

      CategoryName= getIntent().getExtras().get("Category") .toString();
        FData=FirebaseDatabase.getInstance().getReference().child("Products");
        Fstorage=FirebaseStorage.getInstance().getReference().child("Images");
        Toast.makeText(AdminAddProduct.this,CategoryName,Toast.LENGTH_SHORT).show();
        AddProduct=(ImageView)findViewById(R.id.p_image);
        P_Name=(EditText)findViewById(R.id.p_name);
        P_id=(EditText)findViewById(R.id.p_id);
        P_Des=(EditText)findViewById(R.id.p_des);
        P_Price=(EditText)findViewById(R.id.p_price);
        Add=(Button)findViewById(R.id.p_add);
        Next=(Button)findViewById(R.id.p_next);
        //Choose=(Button)findViewById(R.id.choose);
        //Upload=(Button)findViewById(R.id.upload);

        Next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(AdminAddProduct.this, DisplayImagesUser.class);
                startActivity(i);
            }
        });

        AddProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                OpenGallery();
            }

        });

        Add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Validate();
                Intent i=new Intent(AdminAddProduct.this,DisplayImagesUser.class);
                startActivity(i);

            }
        });
    }

    private void Validate() {
        S_name = P_Name.getText().toString();
        S_Id = P_id.getText().toString();
        S_des = P_Des.getText().toString();
        S_price = P_Price.getText().toString();


        if (ImageUri == null) {
            Toast.makeText(this, "Image is mandatory", Toast.LENGTH_SHORT).show();
        } else if (TextUtils.isEmpty(S_name)) {
            Toast.makeText(this, "Name is mandatory", Toast.LENGTH_SHORT).show();
        } else {
            StoreInformation();
        }
    }

    private void StoreInformation() {

        final StorageReference filepath = Fstorage.child(ImageUri.getLastPathSegment() + S_Id);
        final UploadTask uploadtask = filepath.putFile(ImageUri);
        uploadtask.addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                String message = e.toString();
                Toast.makeText(AdminAddProduct.this, "Error:" + message, Toast.LENGTH_SHORT).show();

            }
        }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                Toast.makeText(AdminAddProduct.this, "Image uploaded successfully", Toast.LENGTH_SHORT).show();
                Task<Uri> urltask = uploadtask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                    @Override
                    public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                        if (!task.isSuccessful()) {
                            throw task.getException();
                        }
                        downloadimageurl = filepath.getDownloadUrl().toString();
                        return filepath.getDownloadUrl();
                    }

                }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                    @Override
                    public void onComplete(@NonNull Task<Uri> task) {
                        if (task.isSuccessful()) {
                            downloadimageurl = task.getResult().toString();
                            Toast.makeText(AdminAddProduct.this, "URL successfull", Toast.LENGTH_SHORT).show();
                            SaveInDatabase();
                        }
                    }
                });


            }
        });
    }

    private void SaveInDatabase() {
            HashMap<String, Object> productMap = new HashMap<>();
            productMap.put("product_name", S_name);
            productMap.put("product_im", downloadimageurl);
            productMap.put("product_id", S_Id);
            productMap.put("product_des", S_des);
            productMap.put("product_price", S_price);
            FData.child(S_Id).updateChildren(productMap)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override //wait krna ek sec
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                Toast.makeText(AdminAddProduct.this, "product added successfully", Toast.LENGTH_SHORT).show();
//                                S = S_Id;
//                                SharedPreferences sharedPref = getSharedPreferences("myKey", MODE_PRIVATE);
//                                SharedPreferences.Editor editor = sharedPref.edit();
//                                editor.putString("newid", S);
//                                //  editor.putString("value", mail);
//                                editor.apply();
                            } else {
                                String message = task.getException().toString();
                                Toast.makeText(AdminAddProduct.this, "Error:" + message, Toast.LENGTH_SHORT).show();
                            }

                        }
                    });
        }

    private void OpenGallery() {
        Intent galleryintent = new Intent();
        galleryintent.setAction(Intent.ACTION_GET_CONTENT);
        galleryintent.setType("image/*");
        startActivityForResult(galleryintent, Gallery_Pick);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == Gallery_Pick && resultCode == RESULT_OK && data != null) {
            ImageUri = data.getData();
            AddProduct.setImageURI(ImageUri);
        }
    }
}