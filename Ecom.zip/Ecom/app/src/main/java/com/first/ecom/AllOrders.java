package com.first.ecom;

public class AllOrders {

    private String UserName, UserAddress, UserPhone,product_name,product_des,product_price,product_id,product_im,quantity,orderid;


    public String getOrderid() {
        return orderid;
    }

    public void setOrderid(String orderid) {
        this.orderid = orderid;
    }

    public AllOrders(String userName, String userAddress, String userPhone, String product_name, String product_des, String product_price, String product_id, String product_im, String quantity, String orderid) {
        UserName = userName;
        UserAddress = userAddress;
        UserPhone = userPhone;
        this.product_name = product_name;
        this.product_des = product_des;
        this.product_price = product_price;
        this.product_id = product_id;
        this.product_im = product_im;
        this.quantity = quantity;
        this.orderid = orderid;

    }

    private  AllOrders()
    {

    }
    public String getUserName() {
        return UserName;
    }

    public void setUserName(String userName) {
        UserName = userName;
    }

    public String getUserAddress() {
        return UserAddress;
    }

    public void setUserAddress(String userAddress) {
        UserAddress = userAddress;
    }

    public String getUserPhone() {
        return UserPhone;
    }

    public void setUserPhone(String userPhone) {
        UserPhone = userPhone;
    }

    public String getProduct_name() {
        return product_name;
    }

    public void setProduct_name(String product_name) {
        this.product_name = product_name;
    }

    public String getProduct_des() {
        return product_des;
    }

    public void setProduct_des(String product_des) {
        this.product_des = product_des;
    }

    public String getProduct_price() {
        return product_price;
    }

    public void setProduct_price(String product_price) {
        this.product_price = product_price;
    }

    public String getProduct_id() {
        return product_id;
    }

    public void setProduct_id(String product_id) {
        this.product_id = product_id;
    }

    public String getProduct_im() {
        return product_im;
    }

    public void setProduct_im(String product_im) {
        this.product_im = product_im;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }


}
