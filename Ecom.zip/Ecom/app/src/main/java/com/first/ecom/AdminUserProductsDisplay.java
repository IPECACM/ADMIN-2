package com.first.ecom;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class AdminUserProductsDisplay extends AppCompatActivity {
    // Creating DatabaseReference.
    DatabaseReference AData, OData, OPlaced;
    // Creating RecyclerView.
    RecyclerView recyclerView;
    FirebaseAuth FAuth;
    String currentuser = "";
    // Creating RecyclerView.Adapter.
    com.first.ecom.AdminUserProductRecycler adapter;


    // Creating List of ImageUploadInfo class.
    List<AllOrders> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_user_products_display);
        // Assign id to RecyclerView.
        recyclerView = (RecyclerView) findViewById(R.id.recyclerView3);
//


// Setting RecyclerView size true.
        recyclerView.setHasFixedSize(true);
        FAuth = FirebaseAuth.getInstance();
        currentuser = FAuth.getCurrentUser().getUid();
// Setting RecyclerView layout as LinearLayout.
        recyclerView.setLayoutManager(new LinearLayoutManager(AdminUserProductsDisplay.this));
        SharedPreferences sharedPreferences = getSharedPreferences("myKey", MODE_PRIVATE);
        String value = sharedPreferences.getString("value", "");


        // AData = FirebaseDatabase.getInstance().getReference("Orders Placed").child("Order ids").child(value);
        AData = FirebaseDatabase.getInstance().getReference("Orders");

            AData.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                        AllOrders imageUploadInfo = postSnapshot.getValue(AllOrders.class);

                        String key =postSnapshot.getKey();
                        Log.d("AdminUserProductsDisplay", "key: "+key);
                        imageUploadInfo.setOrderid(key);
                        list.add(imageUploadInfo);

                    }
                    adapter = new com.first.ecom.AdminUserProductRecycler(AdminUserProductsDisplay.this, list);

                    recyclerView.setAdapter(adapter);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });



    }
}