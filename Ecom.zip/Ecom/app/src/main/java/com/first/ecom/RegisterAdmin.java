package com.first.ecom;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class RegisterAdmin extends AppCompatActivity {
    EditText AName,APassword,AEmail,APhone;
    Button ARegister,ALogin;
    ProgressBar Pbar;
    FirebaseAuth fAuth;
    FirebaseDatabase FdataB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_admin);

        AName=(EditText) findViewById(R.id.aname);
        APassword=(EditText)findViewById(R.id.apassword);
        AEmail=(EditText)findViewById(R.id.aemail);
        APhone=(EditText)findViewById(R.id.aphone);
        ARegister=(Button)findViewById(R.id.aregister);
        ALogin=(Button)findViewById(R.id.alogin);
        Pbar=(ProgressBar)findViewById(R.id.progressBar2);
        fAuth=FirebaseAuth.getInstance();
        FdataB=FirebaseDatabase.getInstance();

        //if(fAuth.getCurrentUser()!=null)
        //{
          //  Intent i= new Intent(Register.this,MainActivity.class);
            //startActivity(i);
            //finish();
        //}

        ARegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email=AEmail.getText().toString();
                String password=APassword.getText().toString();
                String name=AName.getText().toString();
                String phone=APhone.getText().toString();

                final RegisterData rData= new RegisterData(email,password,name,phone);


                if(TextUtils.isEmpty(email))
                {
                    AEmail.setError("Email is required");
                    return;
                }

                if(TextUtils.isEmpty(password))
                {
                    APassword.setError("Password is required");
                    return;
                }
                if(password.length()<6)
                {
                    Toast.makeText(RegisterAdmin.this,"Password is too short",Toast.LENGTH_LONG).show();
                    return;

                }
                Pbar.setVisibility(view.VISIBLE);

                fAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                        if(task.isSuccessful()){

                            FdataB.getReference().child("Admin").child(fAuth.getUid()).setValue(rData);
                            Toast.makeText((RegisterAdmin.this),"Created Successfully",Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(getApplicationContext(),MainActivity.class));
                            finish();
                        }
                        else
                        {
                            Toast.makeText((RegisterAdmin.this),"Error !"+ task.getException().getMessage(),Toast.LENGTH_SHORT).show();

                        }


                    }
                });


            }
        });

        ALogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(RegisterAdmin.this,LoginAdmin.class);
                startActivity(i);
            }
        });







    }
}



