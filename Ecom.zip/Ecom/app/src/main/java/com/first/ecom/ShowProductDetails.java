package com.first.ecom;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ShowProductDetails extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_product_details);
    }
}
