package com.first.ecom;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class CartActivity extends AppCompatActivity implements CartRecycler.OnItemClickListener {
    // Creating DatabaseReference.
    DatabaseReference CData,OPlaced,OData;

    // Creating RecyclerView.
    RecyclerView recyclerView;

    // Creating RecyclerView.Adapter
    CartRecycler adapter ;
    String imageUploadInfo;

    TextView CartCid;
    FirebaseAuth FAuth;
    String currentuser="";
    Button PlaceOrder;
    private static final String TAG = CartActivity.class.getName();



    // Creating List of ImageUploadInfo class.
    List<product_details> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);
        PlaceOrder = (Button) findViewById(R.id.placeorder);
        recyclerView = (RecyclerView) findViewById(R.id.recyclerView1);
        CartCid = (TextView) findViewById(R.id.cartcid);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(CartActivity.this));
        recyclerView.setAdapter(adapter);
        FAuth = FirebaseAuth.getInstance();
        currentuser = FAuth.getCurrentUser().getUid();
//         SharedPreferences sharedPreferences = getSharedPreferences("myKey", MODE_PRIVATE);
//         String value = sharedPreferences.getString("value","");
//         CartCid.setText(value);


        CData = FirebaseDatabase.getInstance().getReference("Cart").child("User View").child(currentuser);
        String key= UUID.randomUUID().toString();

        SharedPreferences sharedPref = getSharedPreferences("myKey", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putString("value",key) ;
        editor.apply();
      OPlaced=FirebaseDatabase.getInstance().getReference("Orders Placed").child("Order ids").child(key).child("Products");

//        OData=FirebaseDatabase.getInstance().getReference("Orders");
        CData.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                   for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                       product_details imageUploadInfo = postSnapshot.getValue(product_details.class);
//                    product_details product_id = postSnapshot.child("product_id").getValue(product_details.class);
//                    product_details product_name   = postSnapshot.child("product_name").getValue(product_details.class);
//                    product_details product_des  = postSnapshot.child("product_des").getValue(product_details.class);
//                    product_details product_price   = postSnapshot.child("product_price").getValue(product_details.class);
//                    product_details quantity  = postSnapshot.child("quantity").getValue(product_details.class);
//
//                    list.add(product_name);
//                    list.add(product_price);
//                    list.add(product_des);
//                    list.add(product_id);
//                    list.add(quantity);
                       list.add(imageUploadInfo);

                   }

                adapter = new CartRecycler(getApplicationContext(), list);
                recyclerView.setAdapter(adapter);
                adapter.setOnItemClickListener(CartActivity.this);
            }


            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(CartActivity.this,databaseError.getMessage(), Toast.LENGTH_LONG).show();

            }
        });

        PlaceOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               moveRecord(CData,OPlaced);
            }
        });
    }
//
        private void moveRecord ( final DatabaseReference CData, final DatabaseReference OPlaced){
            ValueEventListener valueEventListener = new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    OPlaced.setValue(dataSnapshot.getValue()).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isComplete()) {
                                Log.d(TAG, "Success!");
                                CData.removeValue();
                            } else {
                                Log.d(TAG, "Copy failed!");
                            }
                        }
                    });
                }

                //
                @Override
                public void onCancelled(DatabaseError databaseError) {
                }
            };
            CData.addListenerForSingleValueEvent(valueEventListener);
        }

    @Override
    public void onDeleteClick(int position) {
            product_details seleteditem=list.get(position);
            final String selectedkey=seleteditem.getProduct_id();
            CData.child(selectedkey).removeValue();
            //OPlaced.child(selectedkey).removeValue();

           // StorageReference imgref=FStorage.getReferenceFromUrl(seleteditem.getImage());

                    Toast.makeText(CartActivity.this,"Item Deleted",Toast.LENGTH_SHORT).show();
                }


}
    
