package com.first.ecom;
public class LoginData {

    String lemail, lpassword;

    public LoginData(String lemail, String lpassword) {
        this.lemail = lemail;
        this.lpassword = lpassword;
    }
    public  LoginData()
    {}

    public String getLemail() {

        return lemail;
    }

    public void setLemail(String lemail) {
        this.lemail = lemail;
    }

    public String getLpassword() {
        return lpassword;
    }

    public void setLpassword(String lpassword) {
        this.lpassword = lpassword;
    }
}

