package com.first.ecom;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView t;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        t=(TextView)findViewById(R.id.textView);

    }

//    public void Logout(View view) {
//
//        FirebaseAuth.getInstance().signOut();
//        Intent i= new Intent(MainActivity.this,Login.class);
//        startActivity(i);
//    }
}

