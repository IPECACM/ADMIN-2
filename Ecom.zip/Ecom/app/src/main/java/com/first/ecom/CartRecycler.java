package com.first.ecom;

import android.content.Context;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CartRecycler extends RecyclerView.Adapter<CartRecycler.ViewHolder> {

    private  Context context;
  private   List<product_details> MainImageUploadInfoList;
    //private  String OverallPrice="0";
    private OnItemClickListener mlistener;

    public CartRecycler(Context context, List<product_details> TempList) {

        this.MainImageUploadInfoList = TempList;

        this.context = context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cart_items, parent, false);

        ViewHolder viewHolder = new ViewHolder(view);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {

            product_details UploadInfo = MainImageUploadInfoList.get(position);
// display cart products added by the user
        holder.productDes.setText(UploadInfo.getProduct_des());
       holder.productId.setText(UploadInfo. getProduct_id());
        holder.productName.setText(UploadInfo.getProduct_name());
        holder.productPrice.setText(UploadInfo.getProduct_price());
        holder.Quantity.setText(UploadInfo.getQuantity());
//        int OneTypeProduct=(Integer.valueOf(UploadInfo.getProduct_price()) * (Integer.valueOf(UploadInfo.getQuantity())));
//        OverallPrice=OverallPrice+OneTypeProduct;



    }

    @Override
    public int getItemCount() {

        return MainImageUploadInfoList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements  View.OnClickListener,View.OnCreateContextMenuListener, MenuItem.OnMenuItemClickListener {

        public ImageView imageView;
        public TextView productDes;
        public TextView productId;
        public TextView productName;
        public TextView productPrice;
        public TextView Quantity;
        public CardView cardView;
        public ViewHolder(View itemView) {
            super(itemView);

            imageView = (ImageView) itemView.findViewById(R.id.imageView);
            productDes= (TextView) itemView.findViewById(R.id.productdes);
            Quantity= (TextView) itemView.findViewById(R.id.q);
            productId = (TextView) itemView.findViewById(R.id.productid);
            productName = (TextView) itemView.findViewById(R.id.productname);
            productPrice = (TextView) itemView.findViewById(R.id.productprice);
            cardView=(CardView)itemView.findViewById(R.id.cardview1);
            itemView.setOnClickListener(this);
            itemView.setOnCreateContextMenuListener(this);
        }
        @Override
        public void onClick(View view) {
            if(mlistener!=null)
            {
                int position =getAdapterPosition();
                if(position!=RecyclerView.NO_POSITION){
                    mlistener.onDeleteClick(position);

                }
            }
        }

        @Override
        public void onCreateContextMenu(ContextMenu contextMenu, View view, ContextMenu.ContextMenuInfo contextMenuInfo) {

            contextMenu.setHeaderTitle("Select Action");
            MenuItem delete=contextMenu.add(Menu.NONE,1,1,"Delete");
            delete.setOnMenuItemClickListener(this);

        }

        @Override
        public boolean onMenuItemClick(MenuItem menuItem) {
            if(mlistener!=null)
            {
                int position =getAdapterPosition();
                if(position!=RecyclerView.NO_POSITION){
                    switch (menuItem.getItemId()){
                        case 1: mlistener.onDeleteClick(position);
                            return true;
                    }

                }
            }
            return false;
        }
    }

    public interface  OnItemClickListener{
        void onDeleteClick(int position);
    }
    public  void setOnItemClickListener(OnItemClickListener listener)

    {
        mlistener=listener;
    }
    }
