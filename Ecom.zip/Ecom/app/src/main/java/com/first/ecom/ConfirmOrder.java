package com.first.ecom;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class ConfirmOrder extends AppCompatActivity {

    private EditText name,phone,address;
    private TextView Display;
    private Button Confirm,Next;
    String O_Name,O_Phone,O_Address;
    DatabaseReference OData;
    DatabaseReference OPlaced,CData;
    FirebaseAuth FAuth;
    String currentuser="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm_order);
        name = (EditText) findViewById(R.id.oname);
        phone = (EditText) findViewById(R.id.ophone);
        address = (EditText) findViewById(R.id.oadd);
        Display=(TextView)findViewById(R.id.display);
        Confirm=(Button)findViewById(R.id.confirm);
        Next=(Button)findViewById(R.id.next1);
        FAuth=FirebaseAuth.getInstance();

        currentuser=FAuth.getCurrentUser().getUid();
        SharedPreferences sharedPreferences = getSharedPreferences("myKey", MODE_PRIVATE);
        String value = sharedPreferences.getString("value","");

        OData = FirebaseDatabase.getInstance().getReference().child("Orders");
        OPlaced= FirebaseDatabase.getInstance().getReference().child("Orders Placed").child("Order ids").child(value);

//        SharedPreferences sharedPref = getSharedPreferences("myKey", MODE_PRIVATE);
//        SharedPreferences.Editor editor = sharedPref.edit();
//        editor.putString("currentuserid",currentuser) ;
//        editor.apply();

//
//        Next.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent i=new Intent(ConfirmOrder.this,AdminOrders.class);
//                startActivity(i);
//            }
//        });

        Confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                   validate();
            }
        });

    }

    private void validate() {

        O_Name=name.getText().toString();
        O_Phone=phone.getText().toString();
        O_Address=address.getText().toString();
        if(TextUtils.isEmpty(O_Name) || (TextUtils.isEmpty(O_Address) || (TextUtils.isEmpty(O_Phone))))
        {
            Toast.makeText(ConfirmOrder.this,"Fill All Details",Toast.LENGTH_SHORT).show();
        }
        else
            SaveDetails();
    }

    private void SaveDetails(){
            HashMap<String,Object> productMap = new HashMap<>();
            productMap.put("UserName", O_Name);
            productMap.put("UserPhone", O_Phone);
            productMap.put("UserAddress", O_Address);
        SharedPreferences sharedPreferences = getSharedPreferences("myKey", MODE_PRIVATE);
        String value = sharedPreferences.getString("value","");

        OData.child(value).updateChildren(productMap)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                Toast.makeText(ConfirmOrder.this, "Details Saved Successfully", Toast.LENGTH_SHORT).show();
                                Intent i=new Intent(ConfirmOrder.this,Login.class);
                                startActivity(i);

                            } else {
                                String message = task.getException().toString();
                                Toast.makeText(ConfirmOrder.this, "Error:" + message, Toast.LENGTH_SHORT).show();

                            }

                        }


                    });
        OrdersPlacedByUser();
        }

    private void OrdersPlacedByUser() {
        HashMap<String, Object> productMap = new HashMap<>();
        productMap.put("UserName", O_Name);
        productMap.put("UserPhone", O_Phone);
        productMap.put("UserAddress", O_Address);
        OPlaced.child("User Details").child(O_Phone).updateChildren(productMap)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(ConfirmOrder.this, "Order Placed Successfully", Toast.LENGTH_SHORT).show();
                            Intent i=new Intent(ConfirmOrder.this,Login.class);
                            startActivity(i);

                        } else {
                            String message = task.getException().toString();
                            Toast.makeText(ConfirmOrder.this, "Error:" + message, Toast.LENGTH_SHORT).show();
                        }

                    }
                });

    }

}









