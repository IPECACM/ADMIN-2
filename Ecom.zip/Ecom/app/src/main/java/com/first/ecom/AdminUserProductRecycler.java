package com.first.ecom;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.first.ecom.R;

import java.util.List;

public class AdminUserProductRecycler extends RecyclerView.Adapter<AdminUserProductRecycler.ViewHolder> {

    Context context;
    List<AllOrders> MainImageUploadInfoList;
    private static final String TAG = AdminUserProductRecycler.class.getName();

    public AdminUserProductRecycler (Context context, List<AllOrders> TempList) {

        this.MainImageUploadInfoList = TempList;

        this.context = context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adminorderproductlayout, parent, false);

        ViewHolder viewHolder = new ViewHolder(view);

        return viewHolder;
    }


    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        final AllOrders UploadInfo = MainImageUploadInfoList.get(position);
        holder.AProductName.setText(UploadInfo.getProduct_name());
        holder.AProductId.setText(UploadInfo.getProduct_id());
        holder.AProductPrice.setText(UploadInfo.getProduct_price());
        holder.AProductQuant.setText(UploadInfo.getQuantity());
        holder.UserName.setText(UploadInfo.getUserName());
        holder.UserPhn.setText(UploadInfo.getUserPhone());
        holder.UserAdd.setText(UploadInfo.getUserAddress());
        holder.cardview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d(TAG, "Success!");
                Intent i=new Intent(context,OrdersPlacedDatabase.class);
                i.putExtra("orderId",UploadInfo.getOrderid());
                context.startActivity(i);
            }
        });

    }

    @Override
    public int getItemCount() {

        return MainImageUploadInfoList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        public TextView AProductId;
        public TextView AProductPrice;
        public TextView AProductQuant;
        public TextView AProductName;
        public  TextView UserAdd;
        public  TextView UserPhn;
        public  TextView UserName;
        public  TextView Orderid;

        public CardView cardview;

        public ViewHolder(View itemView) {
            super(itemView);
            AProductId = (TextView) itemView.findViewById(R.id.cpid);
            AProductPrice = (TextView) itemView.findViewById(R.id.cpprice);
            AProductQuant = (TextView) itemView.findViewById(R.id.cpquant);
            Orderid=(TextView)itemView.findViewById(R.id.oid);
            UserAdd = (TextView) itemView.findViewById(R.id.useradd);
            UserName = (TextView) itemView.findViewById(R.id.username);
            UserPhn = (TextView) itemView.findViewById(R.id.userphn);
            AProductName = (TextView) itemView.findViewById(R.id.cpname);
            cardview=(CardView)itemView.findViewById(R.id.cardview2);

        }
    }
}