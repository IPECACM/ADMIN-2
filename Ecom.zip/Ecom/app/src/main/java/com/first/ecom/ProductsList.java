package com.first.ecom;

public class ProductsList {
    //Products products
}
