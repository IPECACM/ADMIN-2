package com.first.ecom;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Login extends AppCompatActivity {

    EditText l_email,l_password;
    Button Login,Register;
    FirebaseAuth LAuth;
    FirebaseDatabase FdataB;

    DatabaseReference databaseReference;
    static private int i=0;
  // static private int cust_id=0;
    String F;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        l_email=(EditText)findViewById(R.id.L_email);
        l_password=(EditText)findViewById(R.id.L_password);
        Login=(Button)findViewById(R.id.login);
        Register=(Button)findViewById(R.id.Lregister);

        LAuth=FirebaseAuth.getInstance();
        FdataB=FirebaseDatabase.getInstance();
        databaseReference=FdataB.getReference().child("Users");

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String lemail=l_email.getText().toString().trim();
               final String lpassword=l_password.getText().toString().trim();
                final LoginData lData= new LoginData(lemail,lpassword);


                if(TextUtils.isEmpty(lemail))
               {
                   l_email.setError("Email required");
                   return;
               }
               if(TextUtils.isEmpty(lpassword))
               {
                   l_password.setError("Password required");
                   return;
               }
               if(lpassword.length()<6)
               {
                   Toast.makeText(Login.this,"Password is too short",Toast.LENGTH_SHORT).show();
                   return;
               }
                databaseReference.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {
                            if (dataSnapshot1.hasChild("password")) {

                                String mail = dataSnapshot1.child("email").getValue(String.class);
                                String p = dataSnapshot1.child("password").getValue(String.class);
                                //lemail and lpassword that is input by the user
                                if ((mail.equals(lemail)) && (p.equals(lpassword))) {

                                    F=(LAuth.getUid());
                                 //   cust_id=i;

//                                    FdataB.getReference().child("LoggedIn Users").child(String.valueOf(cust_id)).setValue(lData);

                                    FdataB.getReference().child("LoggedIn Users").child(F).setValue(lData);
                                   //  Toast.makeText(com.example.ecom.Login.this,"your customer id is "+cust_id,Toast.LENGTH_SHORT ).show();
                                    Toast.makeText(com.first.ecom.Login.this,"your customer id is "+ F,Toast.LENGTH_SHORT ).show();

                                    SharedPreferences sharedPref = getSharedPreferences("myKey", MODE_PRIVATE);
                                    SharedPreferences.Editor editor = sharedPref.edit();
                                    editor.putString("value",F) ;
                                  //  editor.putString("value", mail);
                                    editor.apply();
//                                    Intent i = new Intent(Login.this, DisplayImagesUser.class);
//                                    startActivity(i);
                                    startActivity(new Intent(getApplicationContext(),DisplayImagesUser.class));
                                    finish();


                                }
                                else{
                                    Toast.makeText(Login.this, "Wronggg", Toast.LENGTH_SHORT).show();
                                }
                            }
                        }

                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

            }

        });

        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(Login.this,Register.class);
                startActivity(i);
            }
        });



    }
}

