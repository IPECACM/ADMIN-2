package com.first.ecom;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoginAdmin extends AppCompatActivity {
    EditText A_email,A_password;
    Button A_Login;
    FirebaseAuth LAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_admin);

        A_email=(EditText)findViewById(R.id.a_email);
        A_password=(EditText)findViewById(R.id.a_password);
        A_Login=(Button)findViewById(R.id.a_login);

        LAuth=FirebaseAuth.getInstance();

       A_Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String aemail=A_email.getText().toString();
                String apassword=A_password.getText().toString();

                if(TextUtils.isEmpty(aemail))
                {
                    A_email.setError("Email required");
                    return;
                }
                if(TextUtils.isEmpty(apassword))
                {
                    A_password.setError("Password required");
                    return;
                }
                if(apassword.length()<6)
                {
                    Toast.makeText(LoginAdmin.this,"Password is too short",Toast.LENGTH_SHORT).show();
                    return;

                }
                LAuth.signInWithEmailAndPassword(aemail,apassword).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful())
                        {
                            Toast.makeText(LoginAdmin.this,"Login Successful",Toast.LENGTH_SHORT).show();
                            Intent i=new Intent(LoginAdmin.this,Admin_Category.class);
                            startActivity(i);
                        }
                        else{
                            Toast.makeText((LoginAdmin.this),"Error !"+ task.getException().getMessage(),Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }

        });




    }
}




