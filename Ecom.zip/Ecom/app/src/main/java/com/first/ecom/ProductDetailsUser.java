package com.first.ecom;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.cepheuen.elegantnumberbutton.view.ElegantNumberButton;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class ProductDetailsUser extends AppCompatActivity {
    private TextView des;
    private TextView price;
    private TextView id;
    private TextView name;
    private TextView quant;
    private  TextView CustomerId;
    private ImageView im;
    private Button Cart;
     String Q,x;
    private ElegantNumberButton e;
    String C_quant;
    String C_id;
    FirebaseAuth FAuth;
//    String Products="Products";
//    static int i=0;
    String C_name;
    SharedPreferences sharedPreferences;
    String C_price;
    String C_des;
   private String productid="";
   // private String phoneuser="";

//    String S_Id="";
    String currentuser="";
    private DatabaseReference FData,CData,OPlaced;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
          super.onCreate(savedInstanceState);
          setContentView(R.layout.activity_product_details_user);
          des = (TextView) findViewById(R.id.pd);
         // ProductId = getIntent().getStringExtra("product_id");
        //    ProductId = getIntent().getStringExtra("product_id");
//
        SharedPreferences sharedPreferences= getSharedPreferences("myKey", MODE_PRIVATE);
        String productid = sharedPreferences.getString("productid","");



        //id.setText(productid);
          price = (TextView) findViewById(R.id.pp);
          CustomerId=(TextView)findViewById(R.id.customerid);
          e=(ElegantNumberButton)findViewById(R.id.elegant);
          Cart=(Button)findViewById(R.id.cart);
          im = (ImageView) findViewById(R.id.im1);
          id = (TextView) findViewById(R.id.pi);
          name = (TextView) findViewById(R.id.pn);
          FData = FirebaseDatabase.getInstance().getReference().child("Products");
          Cart=(Button)findViewById(R.id.cart);
          FAuth=FirebaseAuth.getInstance();
          currentuser=FAuth.getCurrentUser().getUid();
         //Q=id.getText().toString();
          getProductDetails(productid);
       // OrderPlacedbyuser();


//        SharedPreferences sharedPreferences = getSharedPreferences("myKey", MODE_PRIVATE);
//        String newid = sharedPreferences.getString("newid","");
//       id.setText(newid);
//        String value = sharedPreferences.getString("value","");
//        //CustId.setText(value);
//        CustomerId.setText(value);



          Cart.setOnClickListener(new View.OnClickListener() {
              @Override
              public void onClick(View view) {
                  addtocart();
              }
          });
      }

    private void addtocart() {
        C_id=id.getText().toString();
        C_price=price.getText().toString();
        C_name=name.getText().toString();
        C_des=des.getText().toString();
        C_quant= e.getNumber();
        final DatabaseReference CData=FirebaseDatabase.getInstance().getReference().child("Cart");

        final HashMap<String,Object> cartmap=new HashMap<>();
        cartmap.put("product_name", C_name);
        cartmap.put("product_id",C_id);
        cartmap.put("product_des",C_des);
        cartmap.put("product_price",C_price);
        cartmap.put("quantity",C_quant);
        CData.child("User View").child(currentuser).child(C_id).updateChildren(cartmap)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful())
                        {
//                            SharedPreferences sharedPreferences1= getSharedPreferences("myKey", MODE_PRIVATE);
//                            String phone_user = sharedPreferences1.getString("phoneuser","");


                            CData.child("Admin View").child(currentuser).child(C_id).updateChildren(cartmap)
                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    Toast.makeText(ProductDetailsUser.this,"Added to cart",Toast.LENGTH_SHORT).show();
                                    Intent i=new Intent(ProductDetailsUser.this,DisplayImagesUser.class);
                                    startActivity(i);
                                }
                            });
                        }
//                        i++;
                    }
                });

        //OrderPlacedbyuser();

    }

//    public void OrderPlacedbyuser() {
//        final DatabaseReference OPlaced=FirebaseDatabase.getInstance().getReference().child("Orders Placed").child(currentuser).child("Order IDs");
//
//        final HashMap<String,Object> cartmap=new HashMap<>();
//        cartmap.put("product_name", C_name);
//        cartmap.put("product_id",C_id);
//        cartmap.put("product_des",C_des);
//        cartmap.put("product_price",C_price);
//        cartmap.put("quantity",C_quant);
//
//
//
//        OPlaced.child("Products Ordered").child(C_id).updateChildren(cartmap)
//
//                .addOnCompleteListener(new OnCompleteListener<Void>() {
//                    @Override
//                    public void onComplete(@NonNull Task<Void> task) {
//                        if(task.isSuccessful()) {
//                            Toast.makeText(ProductDetailsUser.this, "Added to cart", Toast.LENGTH_SHORT).show();
//                            Intent i = new Intent(ProductDetailsUser.this, DisplayImagesUser.class);
//                            startActivity(i);
//                        }
////                        i++;
//                    }
//                });
//    }

    private void getProductDetails(String productid) {
          //DatabaseReference FData=FirebaseDatabase.getInstance().getReference("Products");
        DatabaseReference Productref=FirebaseDatabase.getInstance().getReference().child("Products");

//        SharedPreferences sharedPreferences = getSharedPreferences("myKey", MODE_PRIVATE);
//        String newid = sharedPreferences.getString("newid","");
//        id.setText(newid);
          Productref.child(productid).addValueEventListener(new ValueEventListener() {
              @Override
              public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                  if (dataSnapshot.exists()) {
                      product_details product_details = dataSnapshot.getValue(product_details.class);
                      name.setText(product_details.getProduct_name());
                      price.setText(product_details.getProduct_price());
                      des.setText(product_details.getProduct_des());
                      id.setText(product_details.getProduct_id());
                    //quant.setText(p.getQuantity());

                    //  Picasso.get().load(p.getProduct_im()).into(im);

                  }
              }


              @Override
              public void onCancelled(@NonNull DatabaseError databaseError) {

              }
          });
    }
}