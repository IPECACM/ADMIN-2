package com.first.ecom;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class AdminOrders extends AppCompatActivity {

    DatabaseReference OData;

    // Creating RecyclerView.
    RecyclerView recyclerView;
    FirebaseAuth FAuth;

    // Creating RecyclerView.Adapter.
    AdminOrderRecycler adapter ;
    String currentuser="";


    // Creating List of ImageUploadInfo class.
    List<user_details> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_orders);
        recyclerView = (RecyclerView) findViewById(R.id.recyclerView2);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(AdminOrders.this));
        FAuth=FirebaseAuth.getInstance();
        currentuser=FAuth.getCurrentUser().getUid();
        OData = FirebaseDatabase.getInstance().getReference("Orders");

        OData.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {

                    user_details imageUploadInfo = postSnapshot.getValue(user_details.class);

                    list.add(imageUploadInfo);
                }

                adapter = new AdminOrderRecycler(getApplicationContext(), list);

                recyclerView.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
