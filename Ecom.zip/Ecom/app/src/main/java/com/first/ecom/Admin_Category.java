package com.first.ecom;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class Admin_Category extends AppCompatActivity {
    ImageView Tshirts,Phones,Laptops,Shoes;
    Button Check;

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin__category);

        Tshirts=(ImageView)findViewById(R.id.tshirts);
        Phones=(ImageView)findViewById(R.id.phone);
        Laptops=(ImageView)findViewById(R.id.laptop);
        Shoes=(ImageView)findViewById(R.id.shoes);
        Check=(Button)findViewById(R.id.check);
        Check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(Admin_Category.this,AdminUserProductsDisplay.class);
                startActivity(i);
            }
        });

        Tshirts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(Admin_Category.this,AdminAddProduct.class);
                i.putExtra("Category","Tshirts");
                startActivity(i);

            }
        });
        Laptops.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(Admin_Category.this,AdminAddProduct.class);
                i.putExtra("Category","Laptops");
                startActivity(i);

            }
        });
        Shoes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(Admin_Category.this,AdminAddProduct.class);
                i.putExtra("Category","Shoes");
                startActivity(i);

            }
        });
        Phones.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(Admin_Category.this,AdminAddProduct.class);
                i.putExtra("Category","Phones");
                startActivity(i);

            }
        });




    }
}
