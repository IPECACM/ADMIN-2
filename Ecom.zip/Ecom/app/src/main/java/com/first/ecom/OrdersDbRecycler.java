package com.first.ecom;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.first.ecom.R;

import java.util.List;

public class OrdersDbRecycler extends RecyclerView.Adapter<OrdersDbRecycler.ViewHolder> {

    Context context;
    List<product_details> MainImageUploadInfoList;
    public OrdersDbRecycler (Context context, List<product_details> TempList) {

        this.MainImageUploadInfoList = TempList;

        this.context = context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.ordersdb, parent, false);

        ViewHolder viewHolder = new ViewHolder(view);

        return viewHolder;
    }


    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        product_details UploadInfo = MainImageUploadInfoList.get(position);
        holder.AProductName.setText(UploadInfo.getProduct_name());
        holder.AProductId.setText(UploadInfo.getProduct_id());
        holder.AProductPrice.setText(UploadInfo.getProduct_price());
        holder.AProductQuant.setText(UploadInfo.getQuantity());

    }

    @Override
    public int getItemCount() {

        return MainImageUploadInfoList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        public TextView AProductId;
        public TextView AProductPrice;
        public TextView AProductQuant;
        public TextView AProductName;

        public CardView cardview;

        public ViewHolder(View itemView) {
            super(itemView);
            AProductId = (TextView) itemView.findViewById(R.id.productid1);
            AProductPrice = (TextView) itemView.findViewById(R.id.productprice1);
            AProductQuant = (TextView) itemView.findViewById(R.id.q1);
            AProductName = (TextView) itemView.findViewById(R.id.productname1);
            cardview=(CardView)itemView.findViewById(R.id.cardview3);

        }
    }
}
