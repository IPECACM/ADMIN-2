package com.first.ecom;
public class user_details {

    private String UserName, UserAddress, UserPhone;


    public user_details(String UserName, String UserAddress, String UserPhone) {
        this.UserName = UserName;
        this.UserAddress = UserAddress;
        this.UserPhone = UserPhone;
    }
    public  user_details(){
    }

    public String getUserName() {
        return UserName;
    }

    public void setUserName(String UserName) {
        this.UserName = UserName;
    }

    public String getUserAddress() {
        return UserAddress;
    }

    public void setUserAddress(String UserAddress) {
        this.UserAddress = UserAddress;
    }

    public String getUserPhone() {
        return UserPhone;
    }

    public void setUserPhone(String UserPhone) {
        this.UserPhone = UserPhone;
    }
}
