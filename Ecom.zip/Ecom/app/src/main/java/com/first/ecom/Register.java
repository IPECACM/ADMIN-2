package com.first.ecom;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Register extends AppCompatActivity {
    EditText Name,Password,Email,Phone;
       TextView Radmin;
        Button Register,Login;
       ProgressBar Pbar;
    //private SharedPreferences sharedPref;
       FirebaseAuth fAuth;
       FirebaseDatabase FdataB;
       String currentuser="";
       DatabaseReference databaseReference;
//       static int CustID=0;
//       static  private  int x=0;
   // private static final  = "prefUserNameKey";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);


        Name=(EditText) findViewById(R.id.R_name);
        Password=(EditText)findViewById(R.id.R_password);
        Email=(EditText)findViewById(R.id.R_email);
        Phone=(EditText)findViewById(R.id.R_phone);
        Register=(Button)findViewById(R.id.register);
        Radmin=(TextView)findViewById(R.id.radmin);
        Login=(Button)findViewById(R.id.Rlogin);
        Pbar=(ProgressBar)findViewById(R.id.progressBar);
        fAuth=FirebaseAuth.getInstance();
        currentuser=fAuth.getCurrentUser().getUid();
        FdataB=FirebaseDatabase.getInstance();




        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email=Email.getText().toString();
                String password=Password.getText().toString();
                String name=Name.getText().toString();
                final String phone=Phone.getText().toString();
//                sharedPref = getPreferences(MODE_PRIVATE);
//                SharedPreferences.Editor editor = sharedPref.edit();
//                editor.putString("CartKey",phone);
//                editor.commit();

                Intent i=new Intent(Register.this,ProductDetailsUser.class);
               // i.putExtra("phone",phone);
                startActivity(i);


                final RegisterData rData= new RegisterData(email,password,phone,name);


                if(TextUtils.isEmpty(email))
                {
                    Email.setError("Email is required");
                    return;
                }

                if(TextUtils.isEmpty(password))
                {
                    Password.setError("Password is required");
                    return;
                }
                if(password.length()<6)
                {
                    Toast.makeText(Register.this,"Password is too short",Toast.LENGTH_LONG).show();
                    return;

                }
                if(TextUtils. isEmpty(name) || (TextUtils.isEmpty(phone)))
                {
                    Toast.makeText(com.first.ecom.Register.this,"Fill All Details",Toast.LENGTH_SHORT).show();
                }
                Pbar.setVisibility(view.VISIBLE);

                fAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                        if(task.isSuccessful())
                        {
//                            CustID=x;
//                            x++;
                            FdataB.getReference().child("Users").child(phone).setValue(rData);
                            Toast.makeText((Register.this),"Created Successfully",Toast.LENGTH_SHORT).show();
//                            Toast.makeText(Register.this,"Your Customer id is " + CustID,Toast.LENGTH_SHORT ).show();
                          startActivity(new Intent(getApplicationContext(),Login.class));
                          finish();
                        }
                        else
                        {
                            Toast.makeText((Register.this),"Error !"+ task.getException().getMessage(),Toast.LENGTH_SHORT).show();

                        }


                    }
                });


            }
        });

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(Register.this,Login.class);
                startActivity(i);
            }
        });

        Radmin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(Register.this,LoginAdmin.class);
                startActivity(i);
            }
        });





    }
}
